# Fonts

ATLAS Meridia uses five Google Fonts families, loaded from the Google Fonts CDN. No local `.ttf` files are bundled — the `@import` in `colors_and_type.css` pulls them at runtime.

| Role | Family | Weights | Notes |
|------|--------|---------|-------|
| Display | **Cormorant Garamond** | 300, 400, 500, 600 (+ italics) | Page titles, section headings, drop caps. Italic is the signature treatment for the wordmark. |
| Body | **Lora** | 400, 500, 600 (+ italics) | Long-form article body, prose. Serif, warm, highly readable. |
| UI | **DM Sans** | 300, 400, 500 (+ italics) | Navigation, buttons, labels, meta text. The only sans. |
| Mono | **IBM Plex Mono** | 400, 500 (+ italics) | Code blocks, inline code, token names. |
| CJK | **Noto Serif TC** | 300, 400, 500, 600 | Traditional Chinese (zh-TW). Used in Living Archive and bilingual content. |

## Why no local files?

Kenny's properties are all deployed on Vercel / Next.js with `next/font` or direct Google Fonts links. Bundling `.ttf` files would duplicate what's already served from Google's CDN and add licensing friction. If you need offline-capable prototypes, download the families from [fonts.google.com](https://fonts.google.com) and self-host them — the CSS variable names stay the same.

## Fallbacks

Fallbacks are tuned so the page still looks in-family before webfonts load:

- Display / Body → `Georgia, serif`
- UI → `system-ui, sans-serif`
- Mono → `ui-monospace, monospace`
- CJK → browser-native CJK serif
