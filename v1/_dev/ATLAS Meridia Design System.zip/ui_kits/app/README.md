# App UI Kit — Hermes / Aeon

High-fidelity recreation of the app chrome used by ATLAS Meridia's agent surfaces (Hermes, Aeon, the Council). Sidebar-driven conversation app with settings pane and composer.

**Components covered:**
- Sidebar (wordmark, conversation list, version badge)
- Header bar (title, status chip, action buttons)
- Conversation view (agent + user turns, timestamps)
- Composer (textarea + send)
- Settings view (theme, token editor preview)
- Empty state

Open `index.html` and click into conversations or the Settings nav item.
