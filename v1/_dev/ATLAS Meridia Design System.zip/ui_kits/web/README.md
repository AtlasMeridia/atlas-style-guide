# Web UI Kit — kennypliu.com / Headless ATLAS

High-fidelity recreation of the long-form reading surface. Single HTML file demonstrating the article layout, a homepage index, and a reading chrome with theme toggle.

**Components covered:**
- Site header (wordmark + nav + theme toggle)
- Homepage index (essay list, meta, feature card)
- Article layout (title, byline, drop cap, prose, blockquote, footnotes)
- Footer (muted, minimal)

**Not in scope:**
- Real CMS integration (Ghost)
- Comments / subscribe flows
- Search

Open `index.html` and use the top nav to move between `Home` and `Article` views.
