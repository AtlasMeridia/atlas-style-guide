---
name: atlas-meridia-design
description: Use this skill to generate well-branded interfaces and assets for ATLAS Meridia (kennypliu.com, Hermes, Aeon, Living Archive, stationery), either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. Apply when the user asks for a mock, slide, landing page, app screen, letterhead, or any surface that should look like Kenny Liu's properties.
user-invocable: true
---

# ATLAS Meridia — design skill

Read `README.md` first — it is the full source of truth on voice, tone, color, type, motion, iconography, and the product surfaces this system covers.

Then orient yourself with:

- `colors_and_type.css` — the token file. Every design MUST import this as the first stylesheet and use `var(--…)` — never hardcode hex or font families. Supports `data-theme="dark"` (default) and `data-theme="light"`.
- `preview/` — one-purpose card specimens for every token family (colors, type, spacing, shadows, motion, components, brand). Open these in a browser when you need to confirm how a token *looks* before using it.
- `ui_kits/web/` — long-form reading surface. Copy its component patterns for anything blog-, article-, or landing-page-shaped.
- `ui_kits/app/` — sidebar + conversation + settings chrome. Copy its component patterns for anything tool-, agent-, or editor-shaped.
- `assets/` — real logos (wordmark + monogram). Copy them into your output folder; never hotlink.
- `fonts/README.md` — fonts are Google-Fonts-CDN-loaded. Link `Cormorant+Garamond`, `Lora`, `DM+Sans`, `IBM+Plex+Mono`, `Noto+Serif+TC`.

## Working rules

1. **Dark is default.** Apply `data-theme="dark"` to `<html>` unless the user asks for light. Paper-noon light theme is the variant, not the default.
2. **Serifs carry the brand.** Cormorant Garamond *italic* for display, Lora for body, DM Sans for UI chrome only. No Inter. No Roboto. No system stack.
3. **One accent color.** Amber-gold (`--accent`, `#c9924a`). Everything else is navy or cream. If a design feels flat, the answer is never "add another color" — it's "use the type scale harder."
4. **No emoji. No gradients. No backdrop blur. No bounce easings. No full-bleed stock photography.** These are invariants.
5. **Sentence case everywhere** except the wordmark (ATLAS Meridia) and proper nouns.
6. **Iconography is Lucide** (CDN) as a Heroicons substitute — 2px stroke, 24px default. Never use emoji or raster icons.
7. **For long-form copy:** set a drop cap on the opening paragraph (amber, display face, `~4.5em`, `float: left`). It's the visual hallmark.

## What to produce

- **Visual artifacts** (slides, mocks, prototypes, landing pages): copy the assets you need into the output folder, write a static HTML file, `<link>` `colors_and_type.css` directly, and use the UI kit components as references. Prefer copying a component pattern over inventing one.
- **Production code:** use tokens verbatim from `colors_and_type.css` (kebab-case CSS custom properties) and cite this skill's README for the rule you're applying. Don't re-derive values.

## When the user invokes this skill without other guidance

Ask:

1. What are you building — a slide, a page, an app screen, stationery, something else?
2. Light or dark theme? (Default dark unless they say otherwise.)
3. How much copy do you have? (If long-form, commit to drop caps and a 608px prose column.)
4. Any specific product surface it should echo — kennypliu.com long-form, Hermes app chrome, or neither?

Then act as an expert designer and return a single HTML file (for mocks) or production code (for real work).
