# ATLAS Meridia Design System

A design system for **kennypliu.com** and related ATLAS Meridia properties — personal publishing, AI tooling, and family archive projects operated by Kenny Liu. Warm desaturated palette, serif-forward typography, dark mode by default.

**Source of truth:** [style.kennypliu.com](https://style.kennypliu.com/) · [github.com/AtlasMeridia/atlas-style-guide](https://github.com/AtlasMeridia/atlas-style-guide)
**Token version:** 4.3.0 (January 2026)

---

## Products represented

ATLAS Meridia is an umbrella for several properties. The tokens in this system are designed to serve all of them consistently:

| Surface | Type | Repo |
|---|---|---|
| **kennypliu.com** / Headless ATLAS | Next.js site + Ghost CMS, long-form writing | `AtlasMeridia/headless-atlas` (private) |
| **atlasm-site** | Business landing page | `AtlasMeridia/atlasm-site` (private) |
| **Hermes** | AI agent interface ("the agent that grows with you") | `AtlasMeridia/hermes-agent` |
| **Aeon** | Local-first AI companion with persistent memory | `AtlasMeridia/aeon` (private) |
| **Living Archive** | Bilingual (EN/zh-TW) Liu family history archive | `AtlasMeridia/living-archive` |
| **Stationery** | Letterhead, envelopes, note cards — half-letter, dotted grid, botanical line art | — |

This design system targets the **two most representative surfaces**: a long-form **web** reading experience (kennypliu.com–style) and an **app** interface (Hermes / Aeon–style). Both share the exact same tokens; only density and component shapes differ.

## Sources

All content below is derived from files in `AtlasMeridia/atlas-style-guide@main`:

- `data/tokens.json` — canonical token definitions (colors, type, spacing, motion, effects, themes)
- `app/globals.css` — embedded tokens for the live editor
- `aesthetic/README.md` + `aesthetic/print/stationery.md` — mood/motif notes
- `app/preview/page.tsx` — reference component recipes (buttons, cards, alerts, prose)
- `components/layout/Sidebar.tsx` / `Header.tsx` — reference chrome (navigation, theme toggle)
- `public/archive/atlas-meridia-style-guide v3_1.html` — historical style guide (not re-fetched; referenced by name)

Assume the reader does **not** have access to private repos — everything needed to design against this system is reproduced locally in this project.

---

## Content Fundamentals

ATLAS Meridia copy is **first-person, essayistic, and quietly confident**. It sounds like a thoughtful technologist writing for themselves and a small audience of peers — not a startup pitching.

### Voice

- **First person, singular.** "I" not "we." Even product pages read as though Kenny is speaking directly. Hermes is tagged *"the agent that grows with you"* — second-person "you" is the reader, "I" is the author.
- **Quiet, not quirky.** No exclamation points. No emoji in product UI or marketing copy. No startup-speak ("revolutionary", "game-changing", "supercharge"). Favor understatement: *"Convene 4 major AI models to independently assess any problem"* over *"Unleash the power of AI!"*.
- **Sentence case, always.** Buttons, headings, navigation. Title Case is reserved for proper nouns and wordmark treatments (ATLAS Meridia, Hermes, Aeon).
- **Concrete over abstract.** Repo descriptions describe mechanism: *"GPU-accelerated particle simulation with flow fields"*, *"Autonomous AI sessions that consume unused Claude Max quota by producing concrete artifacts—tools, writing, and project notes."*
- **Em dashes and ampersands welcome.** The serif stack earns them. Hyphens and em dashes set the rhythm of prose.

### Casing

- UI labels, buttons, section headings: **Sentence case** (`Export CSS`, `Unsaved changes`, `Toggle to Light`).
- Wordmark: **ATLAS** is set in small-caps / all-caps italic muted; **Meridia** / **Style** is set in the primary text color — a two-tone typographic logo. See `components/layout/Sidebar.tsx`.
- Token names: **kebab-case CSS custom properties** (`--navy-900`, `--text-primary`).
- Product names: **Proper case** (Hermes, Aeon, Living Archive).

### Emoji & symbols

- **No emoji in product UI, marketing, or long-form copy.** Ever. The botanical / ink-wash aesthetic is incompatible with emoji.
- Unicode dividers and rule glyphs are used sparingly in code comments and documentation (`═══`, `─`, `·`).
- The bullet-dot `·` is the preferred meta separator (*"Version 4.3.0 · Updated Jan 21, 2026"*).
- No arrow glyphs in UI — use real icons or the word.

### Tone cheatsheet

| Do | Don't |
|---|---|
| "Primary outlet for kennypliu.com and related web properties." | "🚀 The best home for your content!" |
| "Operation completed successfully." | "Success! 🎉 You're all set!" |
| "Please review before continuing." | "⚠️ Heads up!" |
| "December 16, 2025 — 5 min read" | "📖 5 min 🔥" |
| "The agent that grows with you" | "Your AI copilot, supercharged" |

---

## Visual Foundations

The ATLAS Meridia aesthetic is **warm desaturated paper-and-ink**. Imagine a 1970s academic journal reprinted with a single amber spot color, viewed in a lamp-lit room. Dark mode is the room at night.

### Color

- **Two neutral scales**, not one. **Navy** (8 steps, `#08090c` → `#7d8690`) is slightly warm, never cold — no blue cast. **Cream** (6 steps, `#f8f6f1` → `#b8b0a2`) is paper-tinted, never pure white.
- **One signal color: amber-gold** (`#c9924a` default, with light/dark/deep variants). Used for links, accents, drop caps, active states, focus rings. Never neon, never saturated.
- **Semantic colors are muted** — `#6a9a70` success, `#b05454` error — tuned to sit inside the same sepia photo as navy and cream. Warning *is* the accent.
- **No gradients in product UI.** Solid fills only. The only gradient-ish treatment is text-color-mix for underlines (`color-mix(in srgb, var(--accent) 40%, transparent)`).
- **Transparency is used at 10–30%** for tinted surfaces (`bg-[--accent]/10` for highlighted cards, `/30` for success/error chips). Never at 50%+.

### Typography

- **Serif-first.** Display (Cormorant Garamond italic), body (Lora), CJK (Noto Serif TC). Sans (DM Sans) exists only for UI chrome — labels, buttons, meta text.
- **Cormorant Garamond italic is the signature.** It's the wordmark, it's the drop caps, it's every display heading that isn't inside a button.
- **Type scale is aggressive at the top.** `5xl` is 88px, `4xl` is 64px. Long-form pages use hero-sized titles.
- **Body text is 20px** (`--text-body`) — larger than typical web body. Prose is the point.
- **Dark mode uses lighter weights** — `--body-weight: 300` on dark, `400` on light. Serifs can go thin on a dark ground without collapsing.
- **Drop caps** on opening paragraphs of articles (amber, display face, ~4.5em, float left). This is the visual hallmark of the long-form surface.

### Spacing

- **4px base unit.** Scale: 4, 8, 12, 16, 24, 32, 48, 64, 96, 128, 160. No odd values.
- **Prose width is 608px** (`--width-prose`). Wide layouts cap at 832px. Max container is 1280px.
- **Generous vertical rhythm.** Section gaps are `--space-8` (48px) or `--space-12` (96px), not 24px.

### Backgrounds & imagery

- **No full-bleed marketing photography.** Product surfaces are solid color — `--bg-primary` (navy-900 dark / cream-100 light) with occasional `--bg-elevated` blocks for cards.
- **Print work uses spot botanical illustrations** — ginkgo leaves, wrens, chrysanthemums, Chinese ink-style sailboats. Hand-drawn elegance, never full-bleed, always black line art on cream with a dotted grid at 0.25" spacing.
- **No stock photography.** No people smiling at laptops. If imagery appears, it's botanical line art or a book/map/archive artifact photographed neutrally.

### Motion

- **Three durations, one easing.** `--transition-fast` 150ms (hover, focus), `--transition-base` 300ms (theme toggle, reveal), `--transition-slow` 600ms with `cubic-bezier(0.16, 1, 0.3, 1)` (emphasis).
- **Ease-out-expo is the house curve.** Smooth deceleration — things arrive and settle, they don't bounce.
- **No spring physics. No bounces. No parallax.** Motion is quiet.
- **Fade + translate are the default entrance.** Never scale-in from 0.

### Hover & press

- **Hover = subtle border shift.** Borders step from `--border-color` to `color-mix(in srgb, var(--accent) 50%, transparent)` — `hover:border-[--accent]/50`. Not a fill change.
- **Links get a darker underline** on hover (underline-decoration opacity goes from 40% → 100% of accent).
- **Primary button hover** lightens from `--accent` to `--accent-light`. Text on primary is `--navy-950` — dark, not white.
- **Press/active** uses `--accent-deep` (`#8a6530`). No shrink/scale transforms on press.

### Borders & shadows

- **Borders are 1px, `--border-color` (cream-400 / navy-600).** Always. Thicker rules are reserved for blockquotes (`2px accent`, left only).
- **Shadow scale is three steps:** `sm` (1px 2px 10% black), `default` (4px 12px 15% black), `lg` (8px 24px 20% black). Shadows are black-based, never colored.
- **Shadows are reserved for modals and elevated popovers.** Cards at rest use borders, not shadows.

### Radii & cards

- **Three radii.** `sm: 4px`, `default: 6px`, `lg: 12px`. The default is a tight 6px on buttons, inputs, chips. 12px is for cards and larger containers.
- **Cards** = `--bg-elevated` fill + 1px `--border-color` + `12px` radius. No shadow. A highlighted card swaps border for `color-mix(--accent, 30%)`. An accent card uses `bg-[--accent]/10` + `border-[--accent]/20`.

### Transparency & blur

- **No backdrop blur.** Ever. The design is flat.
- **Tinted surfaces via `color-mix` or `/10`–`/30` opacity** — always over solid backgrounds, never stacked.

### Imagery vibe (when present)

- Warm, desaturated, slightly grainy — like a scanned book plate.
- Black-and-white line art for decorative elements.
- Never cool, never neon, never high-contrast Instagram.

### Layout rules

- **No fixed chrome on scroll.** Sidebar is fixed; header is static within the content column. The reader owns the screen.
- **Sidebar** is 256px wide, `--bg-deep`, 1px right border. Present in the editor and app surfaces, omitted from the long-form reading surface.
- **Prose pages are centered** in a 608px column with no sidebar — the reading experience is distraction-free.

---

## Iconography

ATLAS Meridia does **not** use a branded icon font or custom icon system. It uses **inline SVG, stroke-based, 2px width, 24×24 viewBox**, in the Heroicons idiom — the reference codebase (`atlas-style-guide`) hand-rolls icons in this style directly in JSX.

- **Substitute:** [**Lucide**](https://lucide.dev/) is used as the CDN icon set in this design system. It matches the Heroicons stroke weight and metric precisely, is MIT-licensed, and is available via `https://unpkg.com/lucide@latest`. The upstream repo uses hand-rolled Heroicons-style paths; Lucide is a drop-in for prototypes. **Flagged as a substitution** — production code should keep using hand-rolled SVG if that's the pattern in headless-atlas.
- **Never raster.** No PNG icons.
- **Never emoji.** See Content Fundamentals.
- **Unicode characters** are used only in long-form prose typography (em dash, middle dot, curly quotes) — never as UI glyphs.
- **Stroke color follows text color by default.** Icons inside buttons inherit `currentColor`. Accent icons use `text-[--accent]` explicitly.
- **Sizing:** `16px` inline with `--text-sm`, `20px` inline with `--text-base`, `24px` standalone. Nav icons are typically `20px`.

### Logos & assets

Located in `assets/`:

- `logo-wordmark.svg` — "ATLAS Meridia" two-tone italic wordmark (muted / accent).
- `logo-monogram.svg` — square "am" monogram on navy, amber ink. For favicons / app icons.

### Botanical motifs

Print work uses ginkgo, wren, chrysanthemum, and Chinese ink-wash sailboat line art (see `aesthetic/print/stationery.md`). These are **production PSDs** stored in the private `assets-local/stationery/` folder of the upstream repo and are **not** bundled here — request them from Kenny directly if designing print materials. For prototype slide decks or web mocks that need a botanical flourish, leave a placeholder block and flag it.

---

## Index

Root:

- `README.md` — this file
- `colors_and_type.css` — all CSS custom properties + semantic text styles. Import this first.
- `SKILL.md` — Agent Skills manifest for using this system inside Claude Code.
- `assets/` — logos, marks. Copy out, don't hotlink.
- `fonts/README.md` — font documentation (Google Fonts CDN, no local `.ttf`).
- `preview/` — design system preview cards (populate the Design System tab).
- `ui_kits/web/` — long-form web surface (kennypliu.com–style). High-fidelity React recreation.
- `ui_kits/app/` — app chrome surface (Hermes / Aeon–style). Sidebar, conversation, settings.

## Caveats

- Upstream PSD/AI assets (`assets-local/stationery/`) are not included — they're git-ignored in the source repo.
- Fonts use Google Fonts CDN, not bundled `.ttf` files. See `fonts/README.md`.
- Iconography uses **Lucide** as a Heroicons substitute — flagged above.
