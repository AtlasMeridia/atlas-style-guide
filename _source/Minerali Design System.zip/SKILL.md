---
name: minerali-design
description: Use this skill to generate well-branded interfaces and assets in Minerali — the design system behind ATLAS Meridia properties (kennypliu.com, Hermes, Aeon, Living Archive, stationery), for production or throwaway prototypes/mocks. Minerali is the house design language — colors, type, fonts, themes, components. Apply when the user asks for a mock, slide, landing page, app screen, letterhead, or any surface that should look like Kenny Liu's properties.
user-invocable: true
---

# Minerali design skill

Read `README.md` first — the full source of truth on voice, color, type, themes, motion, and iconography. **Minerali is the only direction; the earlier base system (navy/cream/amber, Cormorant/Lora/DM Sans/IBM Plex Mono) is retired — never use it.**

Then orient yourself with:

- `colors_and_type.css` — the token file. Every design MUST link this first and use `var(--…)` — never hardcode hex or font families. Themes: `data-theme="graphite"` (default) or `"cream"` (daylight).
- `preview/` — one-purpose specimens for every token family. Open one in a browser to confirm how a token *looks* before using it.
- `assets/` — real logos (wordmark + monogram). Copy into your output; never hotlink.
- `theme-toggle.js` — self-mounting `<theme-toggle>` switch (graphite ⇄ cream). Copy alongside the CSS; add `<script src="theme-toggle.js" defer>` for a user-facing theme switch.
- `fonts/README.md` — the four families load from Google Fonts CDN: `Fraunces`, `Literata`, `JetBrains Mono`, `Noto Serif TC`.
- `Blog Post.html` — the long-form template. Copy its patterns for anything article-, blog-, or landing-shaped.

## Working rules

1. **Graphite is default.** Apply `data-theme="graphite"` to `<html>` unless asked otherwise. `cream` is daylight — the variant, never the default. (There are only two themes.)
2. **Four faces, one job each.** **Fraunces** (opsz-driven, wonk italic) for display and headings *only*; **Literata** for body and long-form reading; **JetBrains Mono** for all UI chrome, labels, buttons, numbers; **Noto Serif TC** for CJK. No Inter, no Cormorant, no system stack. Fraunces is not the body face — Literata is.
3. **Ink ground, paper text — via the right tokens.** Build grounds on `--bg-primary` / `--bg-elevated` and set text with `--text-primary` / `--text-secondary` — the **theme-aware** tokens, so the surface flips correctly in cream. Reserve the raw `--mn-paper` / `--mn-ink` brand tokens for marks that must *not* theme (the logo, the cut, an always-deep terminal).
4. **One cut, two signals.** **Rust** (`--mn-rust` / `--accent`) is the warm signal — links, drop caps, accents. **Acid** (`--mn-acid` / `--accent-cut`) is *the cut* — use on ≤15% of any surface. If a design feels flat, the answer is never "add a color" — it's "use the type scale and a hairline harder."
5. **Square & flat.** `border-radius: 0`. Dividers and resting borders are 1px `--border-color`. Shadows only on modals/popovers.
6. **No emoji. No gradients. No backdrop blur. No bounce easings. No full-bleed stock photography.** Invariants.
7. **Sentence case everywhere** except the wordmark and proper nouns.
8. **Iconography is Lucide** (CDN) — 2px stroke, 24px default. Never emoji or raster.
9. **Long-form copy:** drop cap on the opening paragraph (rust, Fraunces, ~4.5em, float left) in a 608px column; body set in Literata at 20px.

### Theme toggle

For any surface that should let the reader switch grounds, use `theme-toggle.js` — never hand-roll a switcher. Copy it next to `colors_and_type.css` and add one line: `<script src="theme-toggle.js" defer></script>`. It mounts a fixed top-right control, flips `data-theme` on `<html>`, persists to `localStorage`, and styles itself from the active theme's tokens (no extra CSS). Place a `<theme-toggle></theme-toggle>` tag yourself to anchor it inline instead. Configure via `data-themes` (default `"graphite cream"`), `data-position`, `data-storage-key`. Don't add it to a surface that already controls theme through Tweaks (e.g. `Blog Post.html`) — the two will fight. See `preview/theme-toggle.html`.

Reusable `.mn-*` classes ship in the token file: `.mn-slug`, `.mn-display`, `.mn-tag`, `.mn-btn`, `.mn-knife`, `.mn-hairline`, `.mn-num`. Prefer them over reinventing.

## What to produce

- **Visual artifacts** (slides, mocks, prototypes, pages): copy needed assets into the output folder, write a static HTML file, `<link>` `colors_and_type.css`, set `data-theme="graphite"`, and reuse the `.mn-*` classes and preview patterns. Prefer copying a pattern over inventing one.
- **Production code:** use tokens verbatim from `colors_and_type.css` (kebab-case custom properties); cite the README rule you're applying. Don't re-derive values.

## When invoked without other guidance, ask

1. What are you building — a slide, page, app screen, stationery, something else?
2. Theme — graphite (default) or cream?
3. How much copy? (If long-form, commit to a drop cap and 608px column.)
4. Which surface should it echo — kennypliu.com long-form, Hermes app chrome, or neither?

Then act as an expert designer and return a single HTML file (mocks) or production code (real work).
